import React from 'react';
import Navbar from './component/Navbar'
import LandingPage from './component/LandingPage'
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { ROLL_NUMBER } from './utils/Constants';
import './App.css'
const App = () => {
  return (
    <Router basename={`/${ROLL_NUMBER}`} >
        <Route exact path="/" component={Navbar} />
        <Route path="/LandingPage" component={LandingPage}/>
      </Router>
  );
};
export default App;