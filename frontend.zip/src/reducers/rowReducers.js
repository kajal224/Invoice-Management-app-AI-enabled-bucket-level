const initialState = {
    invoiceRow: []
  };
  
  const rowReducer = (state = initialState, action ) => {
    //console.log(action.data);
    switch (action.type) {
      case "ROW_STORE":
        return {
          ...state,
          invoiceRow: state.invoiceRow.concat(action.data)
        };
      case "ROW_DELETE":
        const index = state.invoiceRow.indexOf(action.data);
        if (index > -1) {
            state.invoiceRow.splice(index, 1);
        }
        return {
          ...state,
          invoiceRow: state.invoiceRow
        };
      default:
        return state;
    }
  };
  
  export default rowReducer;
  