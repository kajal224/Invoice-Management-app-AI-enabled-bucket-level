export const SERVER_URL = 'http://localhost:8080/';
export const ROLL_NUMBER = '1806479'; // Replace <YOUR_ROLL_NUMBER> with your roll number
