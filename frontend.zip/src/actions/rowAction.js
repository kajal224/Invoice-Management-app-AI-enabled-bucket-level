export const rowStore = (demoData) => {
    return {
      type: "ROW_STORE",
      data: demoData
    };
  };
  
  export const rowDelete = (demoData) => {
    return {
      type: "ROW_DELETE",
      data: demoData
    };
  };
  