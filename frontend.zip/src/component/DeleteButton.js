import React, { Component } from "react";
import { Dialog, Button} from "@material-ui/core";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTite from "@material-ui/core/DialogTitle";
import { Remove } from "@material-ui/icons";
import Typography from "@material-ui/core/Typography";
import CloseIcon from "@material-ui/icons/Close";
import "../App.css";
import axios from "axios";
import red from "@material-ui/core/colors/red";
import { ThemeProvider, createMuiTheme } from "@material-ui/core/styles";

const theme = createMuiTheme({
  palette: {
    primary: red
  }
});

const button = {
  margin: "5px",
  borderRadius: 8,
  padding: "7px",
  maxHeight: "30px",
  color: "white",
};
const buttonStyle = {
  margin: "5px",
  padding: "7px",
  maxHeight: "30px",
  color:"white",
  fontSize:"small",
  fontWeight:400,
  border: "1px solid #14AFF1",
  borderRadius:" 11px",
  textTransform:'none',
  opacity: 1,
};

const buttonColor = {
  backgroundColor: "#14aff1",
};
class DeleteButton extends Component {
  constructor() {
    super();
    this.onClickClose = this.onClickClose.bind(this);
    this.state = {
      open: false,
    };
    
  }
  // componentDidMount(){
  //   this.props.data;
  // }

  onClickClose() {
    this.setState({
      open: !this.state.open,
    });
  }
  handelToggle = () => {
    this.setState({
      open: !this.state.open,
    });
  };
  del =async()=>{
    //console.log(this.props.data[0]);

    for(var i=0;i<this.props.data.length;i++)
    {
      console.log(this.props.data[i]+"/"+this.props.data.length);
      const response = await axios.get("http://localhost:8080/1806479/delete?invoiceNo="+this.props.data[i]);
      console.log(response);
      console.log(response.data);
      console.log(response.data.message);
    }


    //this.setState(this.getDefaultState());
  }
  render() {
    const { open } = this.state;

    return (
      <>
        <Button
          className="deleteButton"
          variant="outlined"
          style={buttonStyle}
          onClick={this.handelToggle}
          startIcon={<Remove />}
          disabled = {this.props.data.length<1}
        >
          Delete
        </Button>
        <div className="dialog-div" style={{ backgroundColor: "yellow" }}>
          <Dialog
            open={open}
            onClose={this.handleClose}
            maxWidth="xl"
            PaperProps={{
              style: { backgroundColor: "#2d424f", color: "white" },
            }}
          >
            <DialogTite id="form-dialog-title">
              <div style={{ display: "flex" }}>
                <Typography
                  variant="h6"
                  Component="div"
                  style={{ flexGrow: 1 }}
                >
                  Delete record(s)?
                </Typography>
                <Button
                  onClick={this.onClickClose}
                  color="secondarty"
                  variant="raised"
                  style={button}
                >
                  <CloseIcon />
                </Button>
              </div>
            </DialogTite>
            <DialogContent dividers>
              <Typography>
                You'll lose your record(s) after this action. We can't recover
                them once you delete.
                <br />
                Are you sure you want to{" "}
                <ThemeProvider theme={theme}>
                  <strong color="primary">permanently delete </strong>
                </ThemeProvider>
                them?
              </Typography>
            </DialogContent>
            <DialogActions>
              <div
                style={{
                  display: "flex",
                }}
              >
                <div>
                  <Button
                    className="can-btn"
                    color="primary"
                    variant="raised"
                    onClick={this.onClickClose}
                    style={buttonStyle}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={this.del}
                    color="primary"
                    variant="raised"
                    style={{ buttonStyle, buttonColor }}
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </DialogActions>
          </Dialog>
        </div>
      </>
    );
  }
}
export default DeleteButton;
