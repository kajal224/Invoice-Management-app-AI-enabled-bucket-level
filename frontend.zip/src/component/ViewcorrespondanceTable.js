import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";


export default function ViewcorrespondanceTable({ responseData}) {
  
  return (
    <TableContainer
    >
      <Table stickyHeader aria-label="sticky table">
        <TableHead >
          <TableRow size="size">
            <TableCell>id</TableCell>
            <TableCell align="right">Customer Name</TableCell>
            <TableCell align="right">Customer #</TableCell>
            <TableCell align="right">Invoice #</TableCell>
            <TableCell align="right">Invoice Amount</TableCell>
            <TableCell align="right">Due Date</TableCell>
            <TableCell align="right"> Predicted Payment Date</TableCell>
            <TableCell align="right">Predicted Aging Bucket</TableCell>
            <TableCell align="right">Notes</TableCell>
          

          </TableRow>
        </TableHead>
        <TableBody>
          {responseData.map((row, index) => (
            <TableRow key={index}>
              <TableCell component="th" scope="row">
                {row.id}
              </TableCell>
              <TableCell align="right">{row.name}</TableCell>
              <TableCell align="right">{row.username}</TableCell>
              <TableCell align="right">{row.email}</TableCell>
              <TableCell align="right">{row.phone}</TableCell>
              <TableCell align="right">{row.website}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
