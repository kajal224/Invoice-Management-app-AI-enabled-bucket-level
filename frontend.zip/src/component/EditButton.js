import React, { Component } from "react";
import { Dialog, Button, DialogContentText } from "@material-ui/core";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTite from "@material-ui/core/DialogTitle";
import TextField from "@material-ui/core/TextField";
import { Edit } from "@material-ui/icons";
import Typography from "@material-ui/core/Typography";
import CloseIcon from "@material-ui/icons/Close";
import "../App.css";
import axios from "axios";

const button = {
  margin: "5px",
  borderRadius: 8,
  padding: "7px",
  maxHeight: "30px",
  color: "white",
};

const buttonStyle = {
  margin: "5px",
  padding: "7px",
  maxHeight: "30px",
  color:"white",
  fontSize:"small",
  fontWeight:400,
  border: "1px solid #14AFF1",
  borderRadius:" 11px",
  textTransform:'none',
  opacity: 1,
};
const buttonColor = {
  backgroundColor: "#14aff1",
};

class EditButton extends Component {
  constructor() {
    super();
    this.onClickClose = this.onClickClose.bind(this);
    this.state = {
      open: false,
      empty: this.getDefaultState(),
    };
  }
  onClickClose() {
    this.setState({
      open: !this.state.open,
    });
    this.setState(this.getDefaultState());
  }
  getDefaultState = () => {
    return {
      invoiceAmt: "",
      notes: "",
    };
  };
  clear = () => {
    this.setState(this.getDefaultState());
  };
  save = async() => {
    console.log(this.props.data[0]);
    const response = await axios.get("http://localhost:8080/1806479/edit?invoiceNo="+this.props.data[0]+"&invoiceAmt="+this.state.invoiceAmt+"&notes="+this.state.notes);
    console.log(response);
    console.log(response.data);
    console.log(response.data.message);
    this.setState(this.getDefaultState());
  }
  handelToggle = () => {
    this.setState({
      open: !this.state.open,
    });
  };
  render() {
    const { open } = this.state;
    return (
      <>
        <Button
          className="addButton"
          variant="outlined"
          style={buttonStyle}
          onClick={this.handelToggle}
          startIcon={<Edit />}
          disabled = {this.props.data.length != 1 }
          
        >
          Edit
        </Button>
        <div className="dialog-div" style={{ backgroundColor: "yellow" }}>
          <Dialog
            open={open}
            onClose={this.handleClose}
            maxWidth="xl"
            PaperProps={{
              style: { backgroundColor: "#2d424f", color: "white" },
            }}
          >
            <DialogTite id="form-dialog-title">
              <div style={{ display: "flex" }}>
                <Typography
                  variant="h6"
                  Component="div"
                  style={{ flexGrow: 1 }}
                >
                  Edit invoice
                </Typography>
                <Button
                  onClick={this.onClickClose}
                  color="secondarty"
                  variant="raised"
                  style={button}
                >
                  <CloseIcon />
                </Button>
              </div>
            </DialogTite>
            <DialogContent dividers>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
              <div>Invoice Amount<span style={{color:'#FF5B5B'}}>*</span></div>
                <TextField
                  value={this.state.invoiceAmt}
                  onChange={(e) => {
                    this.setState({ invoiceAmt: e.target.value });
                  }}
                  required
                  type="text"
                  variant="outlined"
                  size="small"
                  style={{ width: "200px", margin: "0 30px" }}
                ></TextField>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                Notes
                <TextField
                  onChange={(e) => {
                    this.setState({ notes: e.target.value });
                  }}
                  value={this.state.notes}
                  required="true"
                  type="text"
                  variant="outlined"
                  size="small"
                  multiline="true"
                  rowsMax="6"
                  style={{ width: "200px", margin: "0 30px" }}
                ></TextField>
              </div>
            </DialogContent>
            <DialogActions>
             
                    <Button onClick={this.onClickClose} variant="raised">
                    <Typography style={{textTransform:'none',color:'#14AFF1'}}>Cancel</Typography>
                    </Button>
                  {/* </div>
                </div>
                <div> */}
                <div style={{flex: '1 1 0'}} />
                  <Button
                    onClick={this.clear}
                    color="primary"
                    variant="outlined"
                    style={buttonStyle}
                    type="reset"
                  >
                    Reset
                  </Button>
                  <Button
                    onClick={this.save}
                    color="primary"
                    variant="contained"
                    style={buttonStyle}
                    style={buttonColor}
                  >
                    <Typography style={{textTransform:'none',borderRadius:" 11px"}}>Save</Typography>
                  </Button>
                
            </DialogActions>
          </Dialog>
        </div>
      </>
    );
  }
}
export default EditButton;
