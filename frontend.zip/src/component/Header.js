import React from 'react';
import abclogo from '../asserts/abclogo.svg';
import companylogo from '../asserts/Companylogo.svg';
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";

function Header(){
return(
    <>
        <div className="header-div">
             <div className="customer-logo">
             <Link to="/">
            <img style={{height:"37px"}} src={abclogo} alt="logo"/>
            </Link>

            </div>
               <p className="company-logo "><img style={{height:"30px"}} src={companylogo} alt="CompanyLogo"/></p>
               </div>
         <div className="invoice-div">
                <p >Invoice List</p>
                </div>

    </>
)
}
export default Header;