import React, { useState } from "react";
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import AddIcon from '@material-ui/icons/Add';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import "../App.css";
import CloseIcon from "@material-ui/icons/Close";
import {View} from 'react-native';
import InfiniteScroll from "react-infinite-scroll-component";
import Fetchtable from './Fetchtable'

const useStyles = makeStyles((theme) => ({
  root: {
    '& > *': {
      margin: theme.spacing(1),
    },
  },
}));

const styles = (theme) => ({
  root: {
    padding: theme.spacing(2),
  },
  closeButton: {
    position: 'absolute',
    right: theme.spacing(1),
    top: theme.spacing(1),
    color: theme.palette.grey[500],
  },
});

const DialogTitle = withStyles(styles)((props) => {
  const { children, classes, onClose, ...other } = props;
  return (
      
    <MuiDialogTitle disableTypography className={classes.root} {...other}>
       
      <Typography variant="h6">{children}</Typography>
      {onClose ? 
            <div  style={{paddingRight:'20px'}}>
            <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
                <CloseIcon />
        </IconButton>
        </div>
       : null }
    </MuiDialogTitle>
  );
});

const StyledButton = withStyles({
  root: {
    background: '#14AFF1',
    color: 'white',
  },
  label: {
    textTransform: 'none',
  },
})(Button);
  
const DialogContent = withStyles((theme) => ({
  root: {
    backgroundColor: "#2A3E4C",
    left: theme.spacing(1),
    right: theme.spacing(1),
    top: theme.spacing(2),
    padding: theme.spacing(2),
  },
}))(MuiDialogContent);

const DialogActions = withStyles((theme) => ({
  root: {
    margin: 0,
    backgroundColor: "#2A3E4C",
    padding: theme.spacing(1),
  },
}))(MuiDialogActions);

export default function ViewCorrespondance() {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  
  return (
    <div>
      <Button variant="outlined" onClick={handleClickOpen} style={{ border: "1px solid #14AFF1", borderRadius:" 11px"}}>
      <Typography style={{textTransform:'none',color:'#FFFFFF'}}>View Correspondance</Typography>
      </Button>
       
      <Dialog onClose={handleClose}  open={open}  maxWidth="xl"  >
         
        <DialogTitle onClose={handleClose}  style={{backgroundColor: '#2A3E4C'}}>
            <div style={{paddingRight:'80px'}}>
            <div style={{float:'left'}}><span style={{color: '#FFFFFF'}}>View Correspondance (2)</span></div>
            <div style={{float:'right'}}><span style={{color: '#C0C6CA',paddingRight:'10px',fontSize :'14px'}}>View: </span>
            <select name="View" style={{backgroundColor:'#283A46',color: '#FFFFFF',height: '30px',width: '130px',borderRadius:'8px',borderColor:'#356680'}}>
           <option style={{color: '#FFFFFF'}}>Template 1</option>
           <option style={{color: '#FFFFFF'}}>Template 2</option>
      </select> </div> 
            </div>
            
           
        </DialogTitle>
        <DialogContent dividers style={{overflowY:'scroll'},{overflowX:'scroll'}}>
        <View style={{color: '#97A1A9'}}>Subject: </View>
        <View style={{color:'#FFFFFF'}}>Invoice Details -</View><br/> <br/>
        <View style={{color: '#C0C6CA'}}>
        Dear Sir/Madam,<br/> Greetings!<br/><br/> This is to remind you that there are one or more open invoices on your account. 
        Please provide at your earliest convenience an update on the payment details or clarify the reason for the delay.
        If you have any specific issue with the invoice(s), please let us know so that we can address it to the correct Department.
        <br/><br/>
         Please find the details of the invoices below:
        </View>
        <Fetchtable/>
        <View style={{color: '#C0C6CA'}}>
        Total Amount to be Paid: $124.00K <br/><br/>
        In case you have already made a payment for the above items, please send us the details to ensure the payment is posted. Let us know if we can be of any further assistance.
        <br/><br/>
        Looking forward to hearing from you. Kind Regards, [Sender’s First Name][Sender’s Last Name] Phone : [Sender’s contact number] Fax : [If any] Email : [Sender’s Email Address] Company Name[Sender’s Company Name]
        </View>
        </DialogContent>
        <DialogActions>
          <Button autoFocus onClick={handleClose} align="left" style={{color:"#14AFF1"}}>
            Cancel
          </Button>
          <div style={{flex: '0 0'}} />
           <StyledButton>Download</StyledButton>
        </DialogActions>
       
      </Dialog>
      </div>
  );
  }