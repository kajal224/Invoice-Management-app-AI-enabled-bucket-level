// import React from "react";
// import BlankBlack from '../asserts/BlankBlack.svg'
// import CheckBox from '../asserts/CheckBox.svg'
// import CalendarTodayIcon from '@material-ui/icons/CalendarToday';

// const Navbar =()=>
// {
//     return(
        
//         <div className="App-background" >
//           <div>  
//         <div className="leftCorner" style={{color: "#14AFF1"}}>UX SCENARIOS</div>
//         <div className="rightCorner" >Other Assets</div>
//         </div>
//         <div>
//         <h6 className="left" style={{color: "#97A1A9"}}>Click 'ABC Products' logo/backdrop to return</h6>
//         <div className="rightCorner">
//         <CalendarTodayIcon/>
//         &nbsp;&nbsp;
//         <img src={BlankBlack}/>
//         &nbsp; &nbsp;
//         <img src={CheckBox}/>
//         </div>    
//         </div>
//         <br/><br/>
//          <React.Fragment> 
//              <div>
//         <div className="left"><a style={{color: "#FFFFFF"}}  href="/LandingPage">
//         Landing Page</a><br/><br/><a style={{color: "#FFFFFF"}}  href="/LandingPage">Rows Selected (Assets)</a><br/><br/>Edit Invoice<br/><br/>View Correspondence/Multiple Template Support<br/><br/>Infinite Scroll in Grid/Loader<br/><br/>
//             </div> 
  
//         <div className="right" ><a style={{color: "#FFFFFF"}}  href="/AddButton">Add Invoice/Calender Picker</a><br/><br/>Confirmation Pop up:Delete Warning<br/><br/>Invoice Search Highlight in Grid<br/><br/>Data Table Empty State (Assets)<br/><br/>Add Invoice Mandatory fields v1:ADD btn DISABLED<br/><br/>Add Invoice Mandatory fields v2:ALER NOTIFICATION (Assets)</div> 
//         </div>
//       </React.Fragment> 
//         </div>
      
      
//     )
// }
// export default Navbar;


import React from "react";
import BlankBlack from "../asserts/BlankBlack.svg";
import CheckBox from "../asserts/CheckBox.svg";
import CalendarTodayIcon from "@material-ui/icons/CalendarToday";
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";

const Navbar = () => {
  return (
    <div className="App-background">
      <div>
        <div className="leftCorner" style={{ color: "#14AFF1" }}>
          UX SCENARIOS
        </div>
        <div className="rightCorner">Other Assets</div>
      </div>
      <div>
        <h6 className="left" style={{ color: "#97A1A9" }}>
          Click 'ABC Products' logo/backdrop to return
        </h6>
        <div className="rightCorner">
          <CalendarTodayIcon />
          &nbsp;&nbsp;
          <img src={BlankBlack} />
          &nbsp; &nbsp;
          <img src={CheckBox} />
        </div>
      </div>
      <br />
      <br />
      <React.Fragment>
        <div>
          <div className="left">
            <Link to="/LandingPage">
              <a style={{ color: "#FFFFFF" }}>Landing Page</a>
            </Link>
            <br />
            <br />
            <Link to="/LandingPage">
            <a style={{ color: "#FFFFFF" }}> Rows Selected (Assets)</a>
            </Link>
            <br />
            <br />
            <Link to="/LandingPage">
            <a style={{ color: "#FFFFFF" }}>
            Edit Invoice
            </a>
            </Link>
            <br />
            <br />
            <Link to="/LandingPage">
            <a style={{ color: "#FFFFFF" }}>
            View Correspondence/Multiple Template Support
            </a>
            </Link>
            <br />
            <br />
            <Link to="/LandingPage">
            <a style={{ color: "#FFFFFF" }}>
            Infinite Scroll in Grid/Loader
            </a>
            </Link>
            <br />
            <br />
          </div>

          <div className="right">
          <Link to="/LandingPage">
            <a style={{ color: "#FFFFFF" }}>
              Add Invoice/Calender Picker
            </a>
            </Link>
            <br />
            <br />
            <Link to="/LandingPage">
            <a style={{ color: "#FFFFFF" }}>
            Confirmation Pop up:Delete Warning
            </a>
            </Link>
            <br />
            <br />
            <Link to="/LandingPage">
            <a style={{ color: "#FFFFFF" }}>
            Invoice Search Highlight in Grid
            </a>
            </Link>
            <br />
            <br />
            <Link to="/LandingPage">
            <a style={{ color: "#FFFFFF" }}>
            Data Table Empty State (Assets)
            </a>
            </Link>
            <br />
            <br />
            <Link to="/LandingPage">
            <a style={{ color: "#FFFFFF" }}>
            Add Invoice Mandatory fields v1:ADD btn DISABLED
            </a>
            </Link>
            <br />
            <br />
            <Link to="/LandingPage">
            <a style={{ color: "#FFFFFF" }}>
            Add Invoice Mandatory fields v2:ALER NOTIFICATION (Assets)
            </a>
            </Link>
          </div>
        </div>
      </React.Fragment>
    </div>
  );
};
export default Navbar;
