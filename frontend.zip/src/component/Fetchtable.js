import React, { useEffect } from "react";
import axios from "axios";
import InfiniteScroll from "react-infinite-scroll-component";
import InceptionTable from "./ViewcorrespondanceTable";
import { makeStyles } from "@material-ui/core/styles";
import ReactTable from 'react-table';
import ViewcorrespondanceTable from "./ViewcorrespondanceTable";

<ReactTable data={InceptionTable} minRows={0} />
 export default function InceptionScroll() {
  // const counter = useSelector((state) => state.invoiceRow); // new
  // const dispatch = useDispatch();

  let [responseData, setResponseData] = React.useState([]);
  useEffect(async () => {
    try {
      const response = await axios.get(
        `https://jsonplaceholder.typicode.com/users`
      );
      setResponseData([...responseData, ...response.data]);
    } catch (error) {
      console.log(error);
    }
  }, []);
    return (
      <>
       <div >
        
          <ViewcorrespondanceTable responseData={responseData} />
        
        </div>
      </>
    );
  }
    
  