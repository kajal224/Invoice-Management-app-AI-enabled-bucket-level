
import React from 'react';
import Button from '@material-ui/core/Button';
import SearchIcon from '@material-ui/icons/Search';
import { TextField, Typography } from '@material-ui/core';
import { Search } from "@material-ui/icons";
import { InputAdornment } from "@material-ui/core";
import Icon from '@material-ui/core/Icon';

const SearchbyInvoiceNumber = () => {
    return(
        <div className="SearchbyInvoiceNumber">
            <TextField
        startIcon={<SearchIcon/>}
         style={{color:'white'}}placeholder="Search Invoice Number "
         InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <Search
                  style={{ color: "white" }}
                />
              </InputAdornment>
            ),
          }}
         ></TextField>
        </div>
    );
};

export default SearchbyInvoiceNumber;


