import React from "react";
import {withStyles, makeStyles,lighten } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Checkbox from "@material-ui/core/Checkbox";
import TextField from '@material-ui/core/TextField';
import blue from "@material-ui/core/colors/blue";

import { ThemeProvider, createMuiTheme } from "@material-ui/core/styles";

import { useDispatch, useSelector } from "react-redux";
import { rowStore, rowDelete } from "../actions/rowAction";
const theme = createMuiTheme({
  palette: {
    primary: blue
  }
});

const useStyles = makeStyles({
    table: {
     
         backgroundColor: '#273D49CC'
        
    },
    checked: {
    color:"#ede8e8",
    },
    root: {
        color: 'blue',
        hover:'true',
        "&$checked": {
            color: "blue"
        }
    },
    container: {
      
      backgroundColor: "#273D49CC",
      background: 'transparent'
    },
   
    tableCell: {
        borderBottom: "none",
        marginBottom:'0%',
        paddingLeft:"1%"
    }
});
const StyledTableRow = withStyles((theme) => ({
  root: {
    '&:nth-of-type(odd)': {
   
      backgroundColor: "#283a46",
borderRadius: "4px",
opacity: 100
    },
  },
}))(TableRow);

export default function InvoiceTable({ responseData }) {
  const classes = useStyles();

  const counter = useSelector((state) => state.invoiceRow); 
  const dispatch = useDispatch();


  return (
    <TableContainer  className={classes.container}>
      <Table aria-label="customized table">
        <TableHead >
          <TableRow> 
            <TableCell  className={classes.tableCell} padding="checkbox" style={{backgroundColor: "#273D49CC"}} > 
            <ThemeProvider theme={theme}>
            <Checkbox className={classes.checked}  color="primary" />
      
    </ThemeProvider>
            </TableCell>
            <TableCell  className={classes.tableCell} style={{backgroundColor: "#273D49CC"}}><div className="font_size" style={{color:"#97A1A9"}}>Customer Name</div></TableCell>
            <TableCell align="right" className={classes.tableCell} style={{backgroundColor: "#273D49CC"}}><div className="font_size" style={{color:"#97A1A9"}}>Customer #</div></TableCell>
            <TableCell align="right" className={classes.tableCell} style={{backgroundColor: "#273D49CC"}} ><div className="font_size" style={{color:"#97A1A9"}}>Invoice #</div></TableCell>
            <TableCell align="right" className={classes.tableCell} style={{backgroundColor: "#273D49CC"}}><div className="font_size" style={{color:"#97A1A9"}}>Invoice Amount</div></TableCell>
            <TableCell align="right" className={classes.tableCell}  style={{backgroundColor: "#273D49CC"}}><div className="font_size" style={{color:"#97A1A9"}}>Due Date  </div></TableCell>
            <TableCell align="right" className={classes.tableCell} style={{backgroundColor: "#273D49CC"}}><div className="font_size" style={{color:"#97A1A9"}}>Predicted Payment Date</div></TableCell>
            <TableCell align="right" className={classes.tableCell}  style={{backgroundColor: "#273D49CC"}}><div className="font_size" style={{color:"#97A1A9"}}>Predicted Aging Bucket</div></TableCell>
            <TableCell align="right" className={classes.tableCell} style={{backgroundColor: "#273D49CC"}}><div className="font_size"style={{color:"#97A1A9"}}>Notes</div></TableCell>
        
          </TableRow>
        </TableHead>
        <TableBody>
          {responseData.map((row, index) => (
            <StyledTableRow key={index}hover>
                 <TableCell className={classes.tableCell}padding="checkbox"><ThemeProvider theme={theme}> <Checkbox  onChange={(e)=>{
                  //console.log(e.target.checked);
                  if(e.target.checked){
                    dispatch(rowStore(row.doc_id));
                  }
                  else{
                    dispatch(rowDelete(row.doc_id));
                  }
                  // console.log(row.doc_id);

                  //  console.log(counter);
                  //  console.log(counter.length);
                 }} className={classes.checked} color="primary"  /> 
                 </ThemeProvider> </TableCell>
          
              <TableCell className={classes.tableCell} ><div className="font_size">{row.name_customer}</div></TableCell>
              <TableCell className={classes.tableCell}   align="right"><div className="font_size">{row.cust_number}</div></TableCell>
              <TableCell className={classes.tableCell}   align="right"><div className="font_size">{row.doc_id}</div></TableCell>
              <TableCell className={classes.tableCell}   align="right"><div className="font_size">{row.total_open_amount}K</div></TableCell>
              <TableCell className={classes.tableCell}   align="right"><div className="font_size">{row.due_in_date}</div></TableCell>
              <TableCell className={classes.tableCell}   align="right"><div className="font_size">{"--"}</div></TableCell>
              <TableCell className={classes.tableCell}   align="right"><div className="font_size">{"--"}</div></TableCell>
              <TableCell className={classes.tableCell}   align="right"><div className="font_size">{row.notes}</div></TableCell>
               
         </StyledTableRow>
           
          ))}
        </TableBody>
        
            
      </Table>
      </TableContainer>
  );
}
