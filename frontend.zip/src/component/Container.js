import React, { useEffect } from "react";
import axios from "axios";
import { CircularProgress } from "@material-ui/core";
import InfiniteScroll from "react-infinite-scroll-component";
import InvoiceTable from "./InvoiceTable";
import { makeStyles } from "@material-ui/core/styles";
import ReactTable from "react-table";
import { Button, Grid, Paper } from "@material-ui/core";
import AddButton from "./AddButton";

import EditButton from "./EditButton.js";
import DeleteButton from "./DeleteButton";
import SearchbyInvoiceNumber from './SearchInvoice';
import ViewCorrespondance from  './ViewCorrespondance';
import { Typography } from '@material-ui/core';


import { useDispatch, useSelector } from "react-redux";


const buttonStyle = {
  margin: "5px",
  padding: "7px",
  maxHeight: "30px",
  color:"white",
  fontSize:"small",
  fontWeight:400,
  border: "1px solid #14AFF1",
  borderRadius:" 11px",
  textTransform:'none',
  opacity: 1,
};
const searchStyle = {
  maxHeight: "8px",
  padding: "2px",
  color: "white",
  
};

const useStyles = makeStyles((theme) => ({
  root: {
    margin: theme.spacing(3),
  },
}));

export default function Container() {
  let [responseData, setResponseData] = React.useState([]);
  let [isNext, isNextFunc] = React.useState(false);
  let [pageCount, setCount] = React.useState(0);

  const counter = useSelector((state) => state.invoiceRow);
  // const dispatch = useDispatch();

  const fetch = async()=>{
    try {
      const response = await axios.get(
        `http://localhost:8080/1806479/retrieve?pageNo=`+(++pageCount)
      );
      setResponseData([...responseData, ...response.data]);
      //console.log(responseData);
      isNextFunc(true);
    } catch (error) {
      console.log(error);
    }
  }

  useEffect( async() => {
    console.log("xxxx");
    fetch();
  }, []);
  <ReactTable data={InvoiceTable} minRows={0} />;

  function fetchMoreData() {
    //console.log(pageCount);
    setCount(+ 1);
    fetch();
  }

  const classes = useStyles();

  return (
    <>
      <div className={classes.root}>
        <div className="content-div" style={{ backgroundColor: "#3b4b62" }}>
          <Paper elevation={5} style={{ backgroundColor: "#273D49CC" }}>
            <Grid container direction="column" color="#273D49CC">
              <Grid item>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    padding: "10px",
                  }}
                >
                  <div
                    className="left_button"
                    style={{
                      display: "flex",
                      justifyContent: "flex-start",
                    }}
                  >
                    <Button
                      variant="outlined"
                      style={{
                        margin: "5px",
                        borderRadius: 8,
                        padding: "7px",
                        maxHeight: "30px",
                        color: "white",
                      }}
                    >
                      <Typography style={{textTransform:'none'}}>Predict</Typography>
                    </Button>
                    
                    <ViewCorrespondance/>
                  </div>
                  <div
                    className="right_button"
                    style={{
                      display: "flex",
                      justifyContent: "flex-end",
                      flex: 2,
                    }}
                  >

                     
                    <AddButton />
                    <EditButton data={counter}/>
                    <DeleteButton data={counter}/>
                    
                    <SearchbyInvoiceNumber/>
                  </div>
                </div>

                <div>
                  <InfiniteScroll
                    dataLength={responseData.length} //length of our responseData
                    next={fetchMoreData} //pass the function which will load more data
                    hasMore={isNext} //whether to call next component while scrolling or not.
                    loader={
                      <div
                        style={{
                          height: "30%",
                          paddingLeft: "48%",
                          overflowX: "scroll",
                          overflowY: "hidden",
                        }}
                      >
                        <CircularProgress />
                        <h6 style={{ color: "white" }}>Loading...</h6>
                      </div>
                    }
                    scrollableTarget="scrollableDiv"
                  >
                    <div>
                      <InvoiceTable responseData={responseData} />
                    </div>
                  </InfiniteScroll>
                </div>
              </Grid>
            </Grid>
          </Paper>
        </div>
      </div>
    </>
  );
}
