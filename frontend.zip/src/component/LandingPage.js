import React from 'react';
import Container from './Container';
import Header from './Header';
function LandingPage()
{
  return(
    <>
    <div className="App-div">
    <Header/>
      <Container/>
      </div>
    </>
  )
}
export default LandingPage;

