import React,{Component}  from "react";
import { Dialog, Button, DialogContentText } from "@material-ui/core";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTite from "@material-ui/core/DialogTitle";
import TextField from "@material-ui/core/TextField";
import { Add } from "@material-ui/icons";
import Typography from "@material-ui/core/Typography";
import CloseIcon from "@material-ui/icons/Close";
import "../App.css";
import axios from "axios";


const button = {
  margin: "5px",
  borderRadius: 8,
  padding: "7px",
  maxHeight: "30px",
  color: "white",
}; 
const buttonStyle = {
  margin: "5px",
  padding: "7px",
  maxHeight: "30px",
  color:"white",
  fontSize:"small",
  fontWeight:400,
  border: "1px solid #14AFF1",
  borderRadius:" 11px",
  textTransform:'none',
  opacity: 1,
};
const buttonColor = {
  borderRadius:" 11px",
  backgroundColor: "#14aff1",
};
const TextfieldStyle = { width: "200px", margin: "0px 30px" };
const divStyle = {
  display: "flex",
  justifyContent: "space-between",
  margin: "10px 0px",
};
class AddButton extends React.Component{
  constructor() {
    super();
    this.onClickClose = this.onClickClose.bind(this);
    this.state = {
      open: false,
      empty: this.getDefaultState(),
    };
  }
  onClickClose() {
    this.setState({
      open: !this.state.open,
    });
    this.setState(this.getDefaultState());
  }
  getDefaultState = () => {
    return {
      custName: "",
      dueDate: "",
      custNo: "",
      notes: "",
      invoiceNo: "",
      invoiceAmt: "",
    };
  };
  clearing = () => {
    this.setState(this.getDefaultState());
  };
  clear =async () => {
    console.log(this.state.custName);
    const response = await axios.get("http://localhost:8080/1806479/add?customerName="+this.state.custName+"&customerNo="+this.state.custNo+"&invoiceNo="+this.state.invoiceNo+"&invoiceAmt="+this.state.invoiceAmt+"&dueDate="+this.state.dueDate+"&notes="+this.state.notes);
    console.log(response);
    console.log(response.data);
    console.log(response.data.message);
    this.setState(this.getDefaultState());
  };
  handelToggle = () => {
    this.setState({
      open: !this.state.open,
    });
  };
  render() {
    const { open } = this.state;
    return (
      <>
        <Button
          className="addButton"
          variant="outlined"
          style={buttonStyle}
          onClick={this.handelToggle}
          startIcon={<Add />}
        >
          Add
        </Button>
        <div className="dialog-div" style={{ backgroundColor: "yellow" }}>
          <Dialog
            open={open}
            onClose={this.handleClose}
            maxWidth="xl"
            PaperProps={{
              style: { backgroundColor: "#2d424f", color: "white" },
            }}
          >
            <DialogTite id="form-dialog-title">
              <div style={{ display: "flex" }}>
                <Typography
                  variant="h6"
                  Component="div"
                  style={{ flexGrow: 1 }}
                >
                  Add invoice
                </Typography>
                <Button
                  onClick={this.onClickClose}
                  color="secondarty"
                  variant="raised"
                  style={button}
                >
                  <CloseIcon />
                </Button>
              </div>
            </DialogTite>
            <DialogContent dividers>
              <div style={{ display: "flex" }}>
                <div style={{ flex: "1" }}>
                  <div style={divStyle}>
                    <div>Customer Name<span style={{color:'#FF5B5B'}}>*</span></div>
                   
                    <TextField
                      value={this.state.custName}
                      onChange={(e) => {
                        this.setState({ custName: e.target.value });
                      }}
                      required
                      type="text"
                      variant="outlined"
                      size="small"
                      style={TextfieldStyle}
                    ></TextField>
                  </div>
                  <div style={divStyle}>
                    <div>Invoice No<span style={{color:'#FF5B5B'}}>*</span></div>
                    <TextField
                      value={this.state.invoiceNo}
                      onChange={(e) => {
                        this.setState({ invoiceNo: e.target.value });
                      }}
                      required
                      type="text"
                      variant="outlined"
                      size="small"
                      style={TextfieldStyle}
                    ></TextField>
                  </div>
                  <div style={divStyle}>
                    <div>Customer No<span style={{color:'#FF5B5B'}}>*</span></div>
                    <TextField
                      value={this.state.custNo}
                      onChange={(e) => {
                        this.setState({ custNo: e.target.value });
                      }}
                      required
                      type="text"
                      variant="outlined"
                      size="small"
                      style={TextfieldStyle}
                    ></TextField>
                  </div>
                  <div style={divStyle}>
                    Notes
                    <TextField
                      value={this.state.notes}
                      onChange={(e) => {
                        this.setState({ notes: e.target.value });
                      }}
                      required
                      type="text"
                      variant="outlined"
                      size="small"
                      multiline="true"
                      rowsMax="6"
                      style={TextfieldStyle}
                    ></TextField>
                  </div>
                </div>
                <div style={{ flex: "1" }}>
                  <div style={divStyle}>
                    <div>Due Date<span style={{color:'#FF5B5B'}}>*</span></div>
                    <TextField
                      value={this.state.dueDate}
                      onChange={(e) => {
                        this.setState({ dueDate: e.target.value });
                      }}
                      required
                      type="Date"
                      variant="outlined"
                      size="small"
                      style={TextfieldStyle}
                    ></TextField>
                  </div>
                  <div style={divStyle}>
                    Invoice Amount<span style={{color:'#FF5B5B'}}>*</span>
                    <TextField
                      value={this.state.invoiceAmt}
                      onChange={(e) => {
                        this.setState({ invoiceAmt: e.target.value });
                      }}
                      required
                      type="text"
                      variant="outlined"
                      size="small"
                      style={TextfieldStyle}
                    ></TextField>
                  </div>
                </div>
              </div>
            </DialogContent>
            <DialogActions>
                  <Button autoFocus onClick={this.onClickClose}  style={{color:"#14AFF1"}}>
                  <Typography style={{textTransform:'none'}}>Cancel</Typography>
                  </Button>
                  <div style={{flex: '1 1 0'}} />
                    <Button onClick={this.clearing}  variant="outined" style={buttonStyle} >
                    <Typography style={{textTransform:'none'},{color:"#FFFFFF"}}>Clear</Typography>
                    </Button>
                  <Button
                    onClick={this.clear}
                    color="primary"
                    variant="contained"
                    style={buttonColor}
                  >
                    <Typography style={{textTransform:'none'}}>Add</Typography>
                  </Button>
            </DialogActions>
          </Dialog>
        </div>
      </>
    );
  }
}
export default AddButton;
