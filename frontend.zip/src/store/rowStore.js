import { createStore } from "redux";
import rowReducer from "../reducers/rowReducers";

const store = createStore(rowReducer);
export default store;
