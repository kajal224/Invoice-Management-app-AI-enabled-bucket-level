package com.higradius;
import java.sql.*;
public class MyPojo {
	private String Business_code;
	private String Cust_number;
	private String Name_customer;
	private Date Clear_date;
	private int Business_year;
	private Long Doc_id;
	private Date Posting_date;
	private Date Document_create_date;
	private Date Due_in_date;
	private String Invoice_currency;
	private String Document_type;
	private short Posting_id;
	private String Area_business;
	private Double TOtal_open_amount;
	private Date Baseline_create_date;
	private String Cust_payment_terms;
	private Long Invoice_id;
	private short IsOpen;
	public String getBusiness_code() {
		return Business_code;
	}
	public void setBusiness_code(String business_code) {
		Business_code = business_code;
	}
	public String getCust_number() {
		return Cust_number;
	}
	public void setCust_number(String cust_number) {
		Cust_number = cust_number;
	}
	public String getName_customer() {
		return Name_customer;
	}
	public void setName_customer(String name_customer) {
		Name_customer = name_customer;
	}
	public Date getClear_date() {
		return Clear_date;
	}
	public void setClear_date(Date clear_date) {
		Clear_date = clear_date;
	}
	public int getBusiness_year() {
		return Business_year;
	}
	public void setBusiness_year(int business_year) {
		Business_year = business_year;
	}
	public Long getDoc_id() {
		return Doc_id;
	}
	public void setDoc_id(Long doc_id) {
		Doc_id = doc_id;
	}
	public Date getPosting_date() {
		return Posting_date;
	}
	public void setPosting_date(Date posting_date) {
		Posting_date = posting_date;
	}
	public Date getDocument_create_date() {
		return Document_create_date;
	}
	public void setDocument_create_date(Date document_create_date) {
		Document_create_date = document_create_date;
	}
	public Date getDue_in_date() {
		return Due_in_date;
	}
	public void setDue_in_date(Date due_in_date) {
		Due_in_date = due_in_date;
	}
	public String getInvoice_currency() {
		return Invoice_currency;
	}
	public void setInvoice_currency(String invoice_currency) {
		Invoice_currency = invoice_currency;
	}
	public String getDocument_type() {
		return Document_type;
	}
	public void setDocument_type(String document_type) {
		Document_type = document_type;
	}
	public short getPosting_id() {
		return Posting_id;
	}
	public void setPosting_id(short posting_id) {
		Posting_id = posting_id;
	}
	public String getArea_business() {
		return Area_business;
	}
	public void setArea_business(String area_business) {
		Area_business = area_business;
	}
	public Double getTOtal_open_amount() {
		return TOtal_open_amount;
	}
	public void setTOtal_open_amount(Double tOtal_open_amount) {
		TOtal_open_amount = tOtal_open_amount;
	}
	public Date getBaseline_create_date() {
		return Baseline_create_date;
	}
	public void setBaseline_create_date(Date baseline_create_date) {
		Baseline_create_date = baseline_create_date;
	}
	public String getCust_payment_terms() {
		return Cust_payment_terms;
	}
	public void setCust_payment_terms(String cust_payment_terms) {
		Cust_payment_terms = cust_payment_terms;
	}
	public Long getInvoice_id() {
		return Invoice_id;
	}
	public void setInvoice_id(Long invoice_id) {
		Invoice_id = invoice_id;
	}
	public short getIsOpen() {
		return IsOpen;
	}
	public void setIsOpen(short isOpen) {
		IsOpen = isOpen;
	}
	
	
}
