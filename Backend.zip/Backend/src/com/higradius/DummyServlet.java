package com.higradius;
import java.io.*;
import java.io.IOException;
import java.sql.*;
import java.sql.Date;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet("/")// experimenting
public class DummyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public DummyServlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
//		Integer pageNo = Integer.parseInt(request.getParameter("pageNo"));
//		
//		PrintWriter writer = response.getWriter();
//        writer.write("<html><body><h1>HelloWorld servlet path : "+action+"</h1></body></html>");
//        writer.close();
		
		
        try {
            switch (action) {
            case "/retrieve":
                retrieveData(request, response);
                break;
            case "/add":
                insertData(request, response);
                break;
            case "/edit":
                editData(request, response);
                break;
            case "/delete":
                deleteData(request, response);
                break;
            case "/search":
                searchData(request, response);
                break;
            case "/fetchingCorrespondence":
                fetchingCorrespondence(request, response);
                break;
            default:
                wrongInput();
                break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
      }
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	//for retrieving table data
	private void retrieveData(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
		
		int pageNo = Integer.parseInt(request.getParameter("pageNo"));
		
        List<MyPojoClass> invoiceList = new InvoiceDao().retrieveTableData(pageNo);
        String json = new Gson().toJson(invoiceList);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(json);

    }
	
	//for inserting data
	private void insertData(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {

        String customerName = request.getParameter("customerName");
        String customerNo = request.getParameter("customerNo");
        Long invoiceNo = Long.parseLong(request.getParameter("invoiceNo")); // assumed invoiceNo == doc id
        Float invoiceAmt = Float.parseFloat(request.getParameter("invoiceAmt"));
        Date dueDate = Date.valueOf(request.getParameter("dueDate"));
        String notes = request.getParameter("notes");

        MyPojoClass newCustomer = new MyPojoClass();

        newCustomer.setName_customer(customerName);
        newCustomer.setCust_number(customerNo);
        newCustomer.setDoc_id(invoiceNo);
        newCustomer.setTotal_open_amount(invoiceAmt);
        newCustomer.setDue_in_date(dueDate);
        newCustomer.setNotes(notes);  // new column needs to be created first
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        if(new InvoiceDao().addInvoiceFunctionality(newCustomer))  // for handling the returned true or false
            {
            response.getWriter().write("{\"done\"=true,message=\"Success\"}");
        	System.out.println("Successful Data Insertion");
            }
        else
            {
            response.getWriter().write("{\"done\"=false,message=\"Error\"}");
        	System.out.println("Unsuccessful Data Insertion");
            }


    }
	
	//for editing data
	private void editData(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {

        Long invoiceNo = Long.parseLong(request.getParameter("invoiceNo"));
        Float invoiceAmt = Float.parseFloat(request.getParameter("invoiceAmt"));
        String notes = request.getParameter("notes");

        MyPojoClass newCustomer = new MyPojoClass();

        newCustomer.setDoc_id(invoiceNo);
        newCustomer.setTotal_open_amount(invoiceAmt);
        newCustomer.setNotes(notes);

        if(new InvoiceDao().editInvoiceFunctionality(newCustomer))  // for handling the returned true or false
            System.out.println("Successful Editing");
        else
            System.out.println("Unsuccessful Editing");

    }

	//for deleting data
	private void deleteData(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {

        Long invoiceNo = Long.parseLong(request.getParameter("invoiceNo"));

        if(new InvoiceDao().deleteInvoiceFunctionality(invoiceNo))  // for handling the returned true or false
            System.out.println("Successful Deleting");
        else
            System.out.println("Unsuccessful Deleting");

    }

	//for searching data
	private void searchData(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Long invoiceNo = Long.parseLong(request.getParameter("invoiceNo"));

        List<MyPojoClass> invoiceList = new InvoiceDao().searchInvoiceFunctionality(invoiceNo);
        String json = new Gson().toJson(invoiceList);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(json);
    }

	//for fetching correspondence 
	private void fetchingCorrespondence(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {

        String customerName = request.getParameter("customerName");

        List<MyPojoClass> invoiceList = new InvoiceDao().viewCorrespondence(customerName);
        String json = new Gson().toJson(invoiceList);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(json);
    }

	//for wrong input
	private void wrongInput() {
        System.out.println("\n Wrong Input \n");
    }
}
