package com.higradius;

import java.sql.*;
import java.sql.Date;
import java.util.*;
import java.io.*;
import com.higradius.MyPojoClass;

public class InvoiceDao {
	String jdbcURL = "jdbc:mysql://localhost/h2h_internship";
    String username = "root";
    String password = "Kajal@123";
    
   // final String csvFilePath = "C:\\Users\\KIIT\\Downloads\\1806479.csv";
    
    String retrieveTableData_query = "select * from invoice_details ";
    
    String addInvoiceFunctionality_query = "INSERT INTO invoice_details"
    		+ "(cust_number,name_customer,due_in_date,total_open_amount,doc_id,notes) "
    		+ "VALUES(?,?,?,?,?,?);";
    
    String editInvoiceFunctionality_query = "UPDATE invoice_details "
    		+ "SET total_open_amount = ?, notes = ? where doc_id = ?;";
    
    String deleteInvoiceFunctionality_query = "DELETE from invoice_details where doc_id = ?;";
    
    String searchFunctionality_query = "SELECT * from invoice_details where doc_id LIKE ?% ;";
    
    String viewCorrespondance_query = "SELECT doc_id, document_create_date,"
    		+ "due_in_date, invoice_currency, total_open_amount WHERE name_customer=?;";
    
    //no sql query for infinite scrolling
    
    public InvoiceDao()
    {    }
    
    protected Connection getConnection()
    {
    	Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, username, password);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return connection;
    }
    //for retrieving table data
    public List<MyPojoClass> retrieveTableData(int pageNo)
    {
    	List<MyPojoClass> tableData = new ArrayList<>();
    	//Establishing connection
    	
    	try(Connection connection = getConnection();
    			PreparedStatement preparedStatement = connection.prepareStatement(retrieveTableData_query+"limit "+String.valueOf((pageNo-1)*10)+","+String.valueOf((pageNo)*10)+";");)
//    			PreparedStatement preparedStatement = connection.prepareStatement(retrieveTableData_query+"offset "
//    	+String.valueOf((pageNo-1)*10)+" fetch next "+String.valueOf((pageNo)*10)+ " rows only;");)
    	{
    		//System.out.println(preparedStatement);
    		ResultSet rs = preparedStatement.executeQuery();
    		
    		// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String 	business_code = rs.getString("business_code");
				String 	cust_number = rs.getString("cust_number");
				String name_customer = rs.getString("name_customer");
				Date clear_date = rs.getDate("clear_date");
				int business_year = rs.getInt("business_year");
				long doc_id = rs.getLong("doc_id");
				Date posting_date = rs.getDate("posting_date");
				Date document_create_date = rs.getDate("document_create_date");
				Date due_in_date = rs.getDate("due_in_date");
				String invoice_currency = rs.getString("invoice_currency");
				String document_type = rs.getString("document_type");
				short posting_id = rs.getShort("posting_id");
				String area_business = rs.getString("area_business");
				float total_open_amount = rs.getFloat("total_open_amount")/1000;
				Date baseline_create_date = rs.getDate("baseline_create_date");
				String cust_payment_terms = rs.getString("cust_payment_terms");
				Long invoice_id = rs.getLong("invoice_id");
				short isOpen = rs.getShort("isOpen");
				String notes = rs.getString("notes");
				tableData.add(new MyPojoClass(business_code,cust_number,name_customer,clear_date,
						business_year,doc_id,posting_date,document_create_date,due_in_date,
						invoice_currency,document_type,posting_id,area_business,total_open_amount,
						baseline_create_date,cust_payment_terms,invoice_id,isOpen,notes));
			}
    	}
    	
    	catch(SQLException e)
    	{
    		printSQLException(e);
    	}
    	
    	return tableData;
    }
    //for adding Invoice functionality
    public boolean addInvoiceFunctionality(MyPojoClass data) throws SQLException
    {
    	boolean rowAdded = false;
    	try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(addInvoiceFunctionality_query))
    	{
    		//"INSERT INTO invoice_details"
    	    		//+ "(cust_number,name_customer,due_in_date,total_open_amount,doc_id,notes) "
    	    		//+ "VALUES(?,?,?,?,?,?);"
    		preparedStatement.setString(1, data.getCust_number());
			preparedStatement.setString(2, data.getName_customer());
			preparedStatement.setDate(3, data.getDue_in_date());
			preparedStatement.setFloat(4, data.getTotal_open_amount());
			preparedStatement.setLong(5, data.getDoc_id());
			preparedStatement.setString(6, data.getNotes());
			//System.out.println(preparedStatement);
			rowAdded = preparedStatement.executeUpdate() > 0;
    	}
    	
    	catch (SQLException e) {
			printSQLException(e);
		}
    	return rowAdded;
    }
    
    //for editing invoice functionality
    public boolean editInvoiceFunctionality(MyPojoClass user) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(editInvoiceFunctionality_query);) {
			//System.out.println("updated USer:"+statement);
			//"SET total_open_amount = ?, notes = ? where doc_id = ?;
			statement.setFloat(1, user.getTotal_open_amount());
			statement.setString(2, user.getNotes());
			statement.setLong(3, user.getDoc_id());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}
    
    //for deleting invoice functionality
    //"DELETE from invoice_details where doc_id = ?;
    public boolean deleteInvoiceFunctionality(Long doc_id) throws SQLException
    {
    	boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(deleteInvoiceFunctionality_query);) {
			statement.setLong(1, doc_id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
    }
    
    //for searching functionality
    public List<MyPojoClass> searchInvoiceFunctionality(Long id)
    {
    	List<MyPojoClass> searchData = new ArrayList<>();
    	//Establishing connection
    	
    	try(Connection connection = getConnection();
    			PreparedStatement preparedStatement = connection.prepareStatement(searchFunctionality_query);)
    	{
    		preparedStatement.setLong(1, id);
    		ResultSet rs = preparedStatement.executeQuery();
    		
    		while (rs.next()) {
				
				String 	cust_number = rs.getString("cust_number");
				String name_customer = rs.getString("name_customer");
				Date clear_date = rs.getDate("clear_date");
				long doc_id = rs.getLong("doc_id");
				Date due_in_date = rs.getDate("due_in_date");				
				float total_open_amount = rs.getFloat("total_open_amount");
				String notes = rs.getString("notes");
				
				searchData.add(new MyPojoClass(cust_number,name_customer,clear_date,
						doc_id,due_in_date,total_open_amount,notes));
			}
    	}
    	catch(SQLException e)
    	{
    		printSQLException(e);
    	}
    	 return searchData;
    }
    
    //for view correspondence functionality
    public List<MyPojoClass> viewCorrespondence(String name)
    {
    	List<MyPojoClass> correspondenceData = new ArrayList<>();
    	//Establishing connection
    	
    	try(Connection connection = getConnection();
    			PreparedStatement preparedStatement = connection.prepareStatement(viewCorrespondance_query);)
    	{
    		preparedStatement.setString(1, name);
    		ResultSet rs = preparedStatement.executeQuery();
    		//"SELECT doc_id, document_create_date,"
    		//+ "due_in_date, invoice_currency, total_open_amount WHERE name_customer=?;
    		while (rs.next()) {
    			long doc_id = rs.getLong("doc_id");
				Date document_create_date = rs.getDate("document_create_date");
				Date due_in_date = rs.getDate("due_in_date");
				String invoice_currency = rs.getString("invoice_currency");
				float total_open_amount = rs.getFloat("total_open_amount");
				
				correspondenceData.add(new MyPojoClass(doc_id, document_create_date, due_in_date,
						invoice_currency, total_open_amount));
			}
    	}
    	catch(SQLException e)
    	{
    		printSQLException(e);
    	}
    	 return correspondenceData;
    }
    
    
    void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}
}
