package com.higradius;

import java.io.*;
import java.sql.*;
import java.util.Objects;
//import java.text.DateFormat;
 
public class Milestone {
 
    public static void main(String[] args) {
        String jdbcURL = "jdbc:mysql://localhost/h2h_internship";
        String username = "root";
        String password = "Kajal@123";
 
        final String csvFilePath = "C:\\Users\\Admin\\1806479.csv";
 
        int batchSize = 100;
 
        Connection connection = null;
 
        try {
 
            connection = DriverManager.getConnection(jdbcURL, username, password);
            connection.setAutoCommit(false);
 
            String sql = "INSERT INTO invoice_details (business_code,cust_number,name_customer,"
            		+ "clear_date,business_year,doc_id,posting_date,document_create_date,due_in_date,"
            		+ "invoice_currency,document_type,posting_id,area_business,total_open_amount,"
            		+ "baseline_create_date,cust_payment_terms,invoice_id, isOpen) "
            		+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            PreparedStatement statement = connection.prepareStatement(sql);
 
            BufferedReader lineReader = new BufferedReader(new FileReader(csvFilePath));
            String lineText = null;
 
            int count = 0;
 
            lineReader.readLine(); 				// skip header line
            MyPojo obj=  new MyPojo();
 
            while ((lineText = lineReader.readLine()) != null) {
                
            	String[] data = lineText.split(",");
               
            	/*
                 * 					CALLING ALL THE SETTER METHODS OF POJO CLASS
                 */
            	
            	obj.setBusiness_code(	data[0]	);
            	obj.setCust_number(	data[1]	);
            	obj.setName_customer(	data[2]	);
            	
            	   //clear date = null or yyyy-MM-dd  eg.2020-01-31 00:00:00
            	//obj.setClear_date(data[3].length() == 0 ? null : Date.valueOf(data[3].substring(0,10)));
            	Date date = data[3].length() == 0 ? null : Date.valueOf(data[3].substring(0,10));
          	  obj.setClear_date(    date    );
            	
            	obj.setBusiness_year(	Integer.parseInt(data[4].substring(0,4))	);
            	obj.setDoc_id(	Long.parseLong(data[5].substring(0,10))		);
            	
            	//	setting up the date format
            	//	doc create date = null or yyyy-MM-dd
           
            	obj.setPosting_date(Date.valueOf(data[6]));
            	
            	
            	
            	data[8] = data[8].length() == 0 ? null : (data[8].substring(0,4)+"-"+data[8].substring(4,6)+"-"+data[8].substring(6));
            	obj.setDocument_create_date(	Date.valueOf(data[8])	); 
            	
            	//	setting up the date format
            	//	due in date = null or yyyy-MM-dd
            	
            	data[9] = data[9].length() == 0 ?null : ( data[9].substring(0,4)+"-"+data[9].substring(4,6)+"-"+data[9].substring(6,8) );
            	obj.setDue_in_date(	Date.valueOf(data[9])	);
            	
            	obj.setInvoice_currency(data[10]);		
            	obj.setDocument_type(data[11]);
            	obj.setPosting_id(	Short.parseShort(data[12].substring(0,1))	);
            	obj.setArea_business(data[13].length()==0?null:data[13]);
            	obj.setTOtal_open_amount(	Double.parseDouble(data[14])	);
            	obj.setBaseline_create_date(	Date.valueOf(data[15].substring(0,4)+"-"+data[15].substring(4,6)+"-"+data[15].substring(6,8))	);
            	obj.setCust_payment_terms(	data[16]	);
            	
            	//	data[17] = invoice_id = 0 or normal case
            	Long temp = data[17].length()==0 ?null :Long.parseLong(data[17].substring(0,10) ) ;
            	obj.setInvoice_id(temp);
            	
            	obj.setIsOpen(Short.parseShort(data[18]));
            	
            	/*
            	 *  		USING ALL THE GETTER METHODS OF SAME POJO CLASS 
            	 */
            	
                statement.setString(1, obj.getBusiness_code());
                statement.setString(2, obj.getCust_number()); 
                statement.setString(3, obj.getName_customer());
                statement.setDate(4, obj.getClear_date());                
                statement.setInt(5, obj.getBusiness_year());
                statement.setLong(6, obj.getDoc_id());
                statement.setDate(7, obj.getPosting_date());
               
                statement.setDate(8, obj.getDocument_create_date());
                statement.setDate(9, obj.getDue_in_date());
                statement.setString(10, obj.getInvoice_currency());
                statement.setString(11, obj.getDocument_type());
                statement.setShort(12, obj.getPosting_id());
                statement.setString(13, obj.getArea_business());
                statement.setDouble(14, obj.getTOtal_open_amount());
                statement.setDate(15, obj.getBaseline_create_date());
                statement.setString(16, obj.getCust_payment_terms());
                if(Objects.isNull(obj.getInvoice_id()))
                    statement.setString(17, null);
                else
                    statement.setLong(17, obj.getInvoice_id());
                statement.setShort(18, obj.getIsOpen());
 
                statement.addBatch();
                count++;
                if (count % batchSize == 0) {
                    statement.executeBatch();
                }
            }
 
            lineReader.close();
 
            // execute the remaining queries
            statement.executeBatch();
 
            connection.commit();
            connection.close();
 
        } catch (IOException ex) {
            System.err.println(ex);
        } catch (SQLException ex) {
            ex.printStackTrace();
 
            try {
                connection.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
 
    }
}

