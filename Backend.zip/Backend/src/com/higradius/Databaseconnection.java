package com.higradius;
import java.sql.*;
import java.util.*;
public class Databaseconnection {
 public static void main(String []args) {
	 Scanner sc=new Scanner(System.in);
  Connection dbCon = null;
  PreparedStatement pstmt1 = null;
  ResultSet rs1 = null;
  PreparedStatement pstmt2 = null;
  ResultSet rs2 = null;
  String url = "jdbc:mysql://localhost/mysql";
  String user = "root";
  String pass = "Kajal@123";
  try {
   Class.forName("com.mysql.cj.jdbc.Driver");
   dbCon = DriverManager.getConnection(url, user, pass);
   if(dbCon!=null)
    System.out.println("Connection successful");
   else
    System.out.println("Connection unsuccessful");
   int f=1;
   while(f==1)
   {
   System.out.println("Press 1 to Fetch and Display whole table data\nPress 2 to fetch alias and quotes column data using serial number\nPress 3 to quit");
   System.out.println("Enter your choice");
   int ch=sc.nextInt();
   switch(ch)
   {
	   case 1:
		   ArrayList<Pojo_class> objlist1 = new ArrayList<>();
		   String query = "select * from Iwar";
		   pstmt1 = dbCon.prepareStatement(query);
		   rs1 = pstmt1.executeQuery();
		   while(rs1.next()) {
			   Pojo_class obj=new Pojo_class();
			   obj.setFirst_name(rs1.getString("First_name"));
			   obj.setLast_name(rs1.getString("Last_name"));
			   obj.setSerial_no(rs1.getInt("Serial_no"));
			   obj.setAlias(rs1.getString("Alias"));
			   obj.setQuotes(rs1.getString("quotes"));
			   objlist1.add(obj);
		      }
		   final Object[][] table1 = new String[4][];
           table1[0] = new String[] { "First_Name", "Last_Name","Serial_no.","Alias","Quotes" };
           int i=1;
           for(Pojo_class ob:objlist1)
           {
               table1[i] = new String[] {String.valueOf(ob.getSerial_no()),ob.getFirst_name(),ob.getLast_name(),ob.getAlias(),ob.getQuotes() };
               i++;
           }
           for (final Object[] row : table1) {
               System.out.format("%15s%20s%20s%30s%30s%n", row);
           }
           System.out.println("");
		   break;
	   case 2:
		   ArrayList<Pojo_class> objlist2 = new ArrayList<>();
		   System.out.println("Enter serial number");
		   int s_no=sc.nextInt();
		   String query2="select alias,quotes from Iwar where serial_no = "+String.valueOf(s_no)+";";
		   pstmt2 = dbCon.prepareStatement(query2);
		   rs2 = pstmt2.executeQuery();
		   while(rs2.next()) {
			   Pojo_class obj=new Pojo_class();
			   obj.setAlias(rs2.getString("Alias"));
			   obj.setQuotes(rs2.getString("quotes"));
			   objlist2.add(obj);
		      }
		   final Object[][] table2 = new String[2][];
           table2[0] = new String[] {"Alias","Quotes"};
           int j=1;
           for(Pojo_class ob:objlist2)
           {
               table2[j] = new String[] {ob.getAlias(),ob.getQuotes() };
               j++;
           }
           for (final Object[] row : table2) {
               System.out.format("%s%30s%n", row);
           }
           System.out.println("");
		   break;
	   case 3:
		   f=0;
		   System.out.println("\nConnection ended");
		   dbCon.close();
		   pstmt1.close();
		   rs1.close(); 
		   pstmt2.close();
		   rs2.close();
		   break;
	   default:
		   System.out.println("Enter a valid choice");
   }   
   }
  }
  catch(SQLException s) {
   s.printStackTrace();
  }
  catch(Exception e) {
   e.printStackTrace();
  }  
 }
}