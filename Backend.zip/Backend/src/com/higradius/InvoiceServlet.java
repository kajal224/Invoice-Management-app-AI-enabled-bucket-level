package com.higradius;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import com.google.gson.Gson;

/**
 * Servlet implementation class InvoiceServlet
 */
@WebServlet("/InvoiceServlet")
public class InvoiceServlet extends HttpServlet {
	public class Employee{
        int postId;
        int id= 1;
        String name;
        String email;
        String body;
        Employee(int postId,int id,String name,String email,String body)
        {
            this.postId=postId;
            this.id=id;
            this.name = name;
            this.email = email;
            this.body = body;
        }
    }
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InvoiceServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
//		String name = request.getParameter("name");
//		Response resp = new Response();
//		resp.setName(name);
//		Gson gson = new Gson();
//		 String data = gson.toJson(resp);
//		 PrintWriter out = response.getWriter();
//		 response.setContentType("application/json");
//		 response.setCharacterEncoding("UTF-8");
//		 out.print(data);
//		 out.flush();
		List<Employee> empList = new ArrayList<>();
        empList.add(new Employee(1,10,"Messi","abc","Soccer"));
        empList.add(new Employee(2,20,"Dhoni", "def","Cricket"));
        empList.add(new Employee(3,30,"Federer", "xyz","LongTennis"));

        String json = new Gson().toJson(empList);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(json);
		
	}
		
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
