package com.higradius;//POJO class

public class Pojo_class {
	private String First_name;
	private String Last_name;
	private int Serial_no;
	private String Alias;
	private String quotes;
	public String getFirst_name() {
		return First_name;
	}
	public void setFirst_name(String first_name) {
		First_name = first_name;
	}
	public String getLast_name() {
		return Last_name;
	}
	public void setLast_name(String last_name) {
		Last_name = last_name;
	}
	public int getSerial_no() {
		return Serial_no;
	}
	public void setSerial_no(int serial_no) {
		Serial_no = serial_no;
	}
	public String getAlias() {
		return Alias;
	}
	public void setAlias(String alias) {
		Alias = alias;
	}
	public String getQuotes() {
		return quotes;
	}
	public void setQuotes(String quotes) {
		this.quotes = quotes;
	}
   }
